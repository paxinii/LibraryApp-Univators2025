﻿namespace LibraryApp.Models
{
    public class Synopsis
    {
        public int Id { get; set; }
        public DateOnly PublicationDate { get; set; }
    }
}
