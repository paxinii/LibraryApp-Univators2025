﻿namespace LibraryApp.Models;

public enum Genre
{
    Fiction,
    NonFiction,
    Mystery,
    Fantasy,
    ScienceFiction,
    Biography,
    Romance,
    Thriller,
    Horror,
    HistoricalFiction
}
